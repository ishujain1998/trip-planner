"""Main entry point for the app.

This app is generated based on your prompt in Vertex AI Studio using
Google GenAI Python SDK (https://googleapis.github.io/python-genai/) and
Gradio (https://www.gradio.app/).

You can customize the app by editing the code in Cloud Run source code editor.
You can also update the prompt in Vertex AI Studio and redeploy it.
"""

import base64
from google import genai
from google.genai import types
import gradio as gr
import utils


def generate(
    message,
    history: list[gr.ChatMessage],
    start_date,
    end_date,
    source_city_state_country,
    destination_city_state_country,
    traveler_age,
    budget,
    travel_style,
    must_do_activities_interests,
    deal_breakers,
    request: gr.Request
):
  """Function to call the model based on the request."""

  validate_key_result = utils.validate_key(request)
  if validate_key_result is not None:
    yield validate_key_result
    return

  client = genai.Client(
      vertexai=True,
      project="adept-crossing-471906-n4",
      location="global",
  )
  msg1_text1 = types.Part.from_text(text=f"""User Input:

Travel Dates: {start_date} to {end_date}
Source: {source_city_state_country}
Destination: {destination_city_state_country}
Traveler Profile: Solo female traveler, {traveler_age}
Budget: {budget} (e.g., Luxury, Mid-range, Budget-conscious)
Travel Style: {travel_style} (e.g., Relaxing, Adventurous, Cultural, Food-focused, etc.)
Must-Do Activities/Interests: {must_do_activities_interests} (List 3-5 specific activities or interests)
Deal-Breakers: {deal_breakers} (e.g., \"No long car journeys,\" \"Must have a pool,\" etc.)

Roles and Responsibilities:

Hotel Agent:
Identify and book the best hotels based on the following criteria:
Luxury & Comfort: 5-star or highly-rated boutique hotels.
Prime Location: Centrally located with easy access to attractions, but in a safe and well-lit area.
Amenities: Spa, fine dining, and excellent concierge service.
User Ratings: Must have consistently high ratings from solo female travelers.

Car Rental Agent:
Secure the best car rental options based on the following criteria:
Reliability: Top-tier rental companies with well-maintained, new-model vehicles.
Safety Features: Advanced safety features (e.g., lane assist, blind-spot monitoring).
Convenience: Easy pickup/drop-off locations, including airport service.
Discretion: Cars that don't stand out unnecessarily.

Security Agent (Solo Female Travel Expert):
Focus on the unique needs of a solo female traveler.
Route Safety: Analyze and recommend the safest routes between locations, especially for late-night travel.
Neighborhood Vetting: Provide a detailed safety profile of all recommended neighborhoods and attractions.
Emergency Planning: Provide information on local emergency services and safe-haven locations.
Behavioral Advice: Offer proactive advice on local customs, dress codes, and situational awareness to avoid potential risks.
Review Analysis: Specifically review hotel and activity feedback from other solo female travelers for safety red flags.

Master Coordinator:
Synthesize Data: Combine the findings from the Hotel, Car Rental, and Security Agents into a single, cohesive itinerary.
Create Timeline: Develop a minute-by-minute or hour-by-hour schedule, including travel times, check-in/out, and activity bookings.
Optimize Efficiency: Ensure the plan is logical and minimizes wasted time.
Provide Options: Offer 2-3 alternative choices for each major booking (e.g., Hotel A, B, and C with pros and cons).
Deliver Final Plan: Present the complete, polished itinerary in a clear, easy-to-read format.

Instructions:

The Master Coordinator will orchestrate the entire process, gathering information from each agent and creating the final itinerary.

The final plan should be a detailed document including:

Executive Summary: A brief overview of the trip.
Day-by-Day Itinerary:
Morning, Afternoon, Evening schedule.
Recommendations for meals.
Specific activities with booking links.
Accommodation Details:
Hotel Name(s), Address, Contact Info.
Specific safety notes from the Security Agent.
Transportation Plan:
Car rental information.
Recommended routes with security notes.
Alternatives (e.g., public transport, trusted ride-share apps).
Safety & Security Briefing:
A dedicated section with tips, local emergency numbers, and a list of safe zones.
Cost Breakdown: An estimated cost for accommodation, transportation, and activities.
Contingency Plan: What to do in case of common travel issues (e.g., lost luggage, flight delays).

Output Format:

Present the complete, polished itinerary in a clear, easy-to-read format. Ensure all recommendations align with the traveler's profile, budget, and travel style. Prioritize safety and efficiency throughout the itinerary.""")
  si_text1 = types.Part.from_text(text=f"""You are a team of AI specialists collaborating to create a comprehensive and personalized travel itinerary. Your team consists of a Hotel Agent, a Car Rental Agent, a Security Agent (Solo Female Travel Expert), and a Master Coordinator. Each member has specific expertise and responsibilities.""")


  model = "gemini-2.5-flash-image-preview"
  contents = [
    types.Content(
      role="user",
      parts=[
        msg1_text1
      ]
    ),
  ]

  for prev_msg in history:
    role = "user" if prev_msg["role"] == "user" else "model"
    parts = utils.get_parts_from_message(prev_msg["content"])
    if parts:
      contents.append(types.Content(role=role, parts=parts))

  if message:
    contents.append(
        types.Content(role="user", parts=utils.get_parts_from_message(message))
    )

  generate_content_config = types.GenerateContentConfig(
      temperature=1,
      top_p=0.95,
      max_output_tokens=32768,
      response_modalities=["TEXT", "IMAGE"],
      safety_settings=[
          types.SafetySetting(
              category="HARM_CATEGORY_HATE_SPEECH",
              threshold="OFF"
          ),
          types.SafetySetting(
              category="HARM_CATEGORY_DANGEROUS_CONTENT",
              threshold="OFF"
          ),
          types.SafetySetting(
              category="HARM_CATEGORY_SEXUALLY_EXPLICIT",
              threshold="OFF"
          ),
          types.SafetySetting(
              category="HARM_CATEGORY_HARASSMENT",
              threshold="OFF"
          )
      ],
      system_instruction=[si_text1],
  )

  results = []
  for chunk in client.models.generate_content_stream(
      model=model,
      contents=contents,
      config=generate_content_config,
  ):
    if chunk.candidates and chunk.candidates[0] and chunk.candidates[0].content:
      results.extend(
          utils.convert_content_to_gr_type(chunk.candidates[0].content)
      )
      if results:
        yield results

with gr.Blocks(theme=utils.custom_theme) as demo:
  with gr.Row():
    gr.HTML(utils.public_access_warning)
  with gr.Row():
    with gr.Column(scale=1):
      with gr.Row():
        gr.HTML("<h2>Welcome to Vertex AI GenAI App!</h2>")
      with gr.Row():
        gr.HTML("""This prototype was built using your Vertex AI Studio prompt.
            Follow the steps and recommendations below to begin.""")
      with gr.Row():
        gr.HTML(utils.next_steps_html)

    with gr.Column(scale=2, variant="panel"):
      gr.ChatInterface(
          fn=generate,
          title="Travel Planning System",
          type="messages",
          multimodal=True,
          additional_inputs=[
              gr.Textbox(label="start_date"),
              gr.Textbox(label="end_date"),
              gr.Textbox(label="source_city_state_country"),
              gr.Textbox(label="destination_city_state_country"),
              gr.Textbox(label="traveler_age"),
              gr.Textbox(label="budget"),
              gr.Textbox(label="travel_style"),
              gr.Textbox(label="must_do_activities_interests"),
              gr.Textbox(label="deal_breakers"),
          ],
          flagging_mode="never",
      )
  demo.launch(show_error=True)